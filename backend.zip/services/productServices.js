const Product = require('../models/ProductModel');

// async function getAllProducts() {
//     try {
//         const products = await Product.find();
//         return products;
//     } catch (error) {
//         throw new Error('Error while fetching products: ' + error.message);
//     }
// }

module.exports = {
    // getAllProducts
}
