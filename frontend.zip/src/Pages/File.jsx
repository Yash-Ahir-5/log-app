import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Select, MenuItem, Button, FormControl, InputLabel, Typography, Container, List, ListItem, ListItemText, ListItemIcon } from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';

function VendorFolders() {
    const [folders, setFolders] = useState([]);
    const [selectedFolder, setSelectedFolder] = useState('');
    const [logs, setLogs] = useState([]);

    useEffect(() => {
        fetchFolders();
    }, []);

    // useEffect(() => {
        
    // }, []);

    const fetchFolders = async () => {
        try {
            const response = await axios.get('http://localhost:4000');
            setFolders(response.data);
        } catch (error) {
            console.error('Error fetching folders:', error);
        }
    };

    const handleStartInserting = async () => {
        const eventSource = new EventSource(`http://localhost:4000/file/${selectedFolder}`);

        eventSource.onmessage = (event) => {
            const newLog = JSON.parse(event.data);
            setLogs(prevLogs => [...prevLogs, newLog]);
        };

        eventSource.onerror = (error) => {
            console.error('EventSource error:', error);
            eventSource.close();
        };
        
    };
    
    return (
        <>
        <br/><br/><br/>
        <Container maxWidth="sm">
            <FormControl fullWidth>
                <InputLabel id="folder-select-label">Folder</InputLabel>
                <Select
                    labelId="folder-select-label"
                    id="folder-select"
                    value={selectedFolder}
                    label="Folder"
                    onChange={(e) => setSelectedFolder(e.target.value)}
                >
                    <MenuItem value="">
                        <em>Select a folder</em>
                    </MenuItem>
                    {folders.map(folder => (
                        <MenuItem key={folder} value={folder}>{folder}</MenuItem>
                    ))}
                </Select>
            </FormControl>
            <Button variant="contained" color="primary" onClick={handleStartInserting} style={{ marginTop: 20 }}>
                Start Inserting
            </Button>
            <Typography variant="h6" style={{ marginTop: 20 }}>Logs:</Typography>
            <List>
                {logs.map((log, index) => (
                    <ListItem key={index} disableGutters>
                        <ListItemIcon>
                            {log.type === 'success' ? <CheckCircleIcon color="success" /> : <ErrorIcon color="error" />}
                        </ListItemIcon>
                        <ListItemText primary={log.message} />
                    </ListItem>
                ))}
            </List>
        </Container>
        </>
    );
}

export default VendorFolders;
