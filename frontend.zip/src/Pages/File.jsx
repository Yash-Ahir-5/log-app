import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Select, MenuItem, Button, FormControl, InputLabel, Typography, Container, List, ListItem, ListItemText, ListItemIcon } from '@mui/material';
import { CheckCircle as CheckCircleIcon, Error as ErrorIcon, Warning as WarningIcon } from '@mui/icons-material';

function VendorFolders() {
    const [folders, setFolders] = useState([]);
    const [selectedFolder, setSelectedFolder] = useState('');
    const [logs, setLogs] = useState([]);
    const [fileStatus, setFileStatus] = useState({});

    useEffect(() => {
        fetchFolders();
        fetchFileStatus();
    }, []);

    const fetchFolders = async () => {
        try {
            const response = await axios.get('http://localhost:4000');
            setFolders(response.data);
        } catch (error) {
            console.error('Error fetching folders:', error);
        }
    };

    const fetchFileStatus = async () => {
        try {
            const response = await axios.get('http://localhost:4000/filestatus');
            setFileStatus(response.data);
            console.log("File DATA STATUS" ,fileStatus);
        } catch (error) {
            console.error('Error fetching file status:', error);
        }
    };

    const handleStartInserting = async () => {
        const eventSource = new EventSource(`http://localhost:4000/file/${selectedFolder}`);

        eventSource.onmessage = (event) => {
            const newLog = JSON.parse(event.data);
            setLogs(prevLogs => [...prevLogs, newLog]);
        };

        eventSource.onerror = (error) => {
            // console.error('EventSource error:', error);
            eventSource.close();
        };
    };

    const getBackgroundColor = (type) => {
        switch (type) {
            case 'success':
                return 'lightgreen';
            case 'update':
                return 'lightblue';
            case 'skip':
                return 'lightyellow';
            case 'error':
                return 'lightcoral';
            default:
                return 'transparent';
        }
    };

    return (
        <>
            <br /><br /><br />
            <Container maxWidth="sm">
                <FormControl fullWidth>
                    <InputLabel id="folder-select-label">Folder</InputLabel>
                    <Select
                        labelId="folder-select-label"
                        id="folder-select"
                        value={selectedFolder}
                        label="Folder"
                        onChange={(e) => setSelectedFolder(e.target.value)}
                    >
                        <MenuItem value="">
                            <em>Select a folder</em>
                        </MenuItem>
                        {folders.map(folder => (
                            <MenuItem key={folder} value={folder}>{folder}</MenuItem>
                        ))}
                    </Select>
                </FormControl>
                <Button variant="contained" color="primary" onClick={handleStartInserting} style={{ marginTop: 20 }}>
                    Start Inserting
                </Button>
                <Typography variant="h6" style={{ marginTop: 20 }}>Logs:</Typography>
                <div style={{ height: '60vh', overflowY: 'auto' }}>
                    <List>
                        {logs.map((log, index) => {
                            const backgroundColor = getBackgroundColor(log.type);
                            return (
                                <ListItem key={index} disableGutters style={{ backgroundColor }}>
                                    <ListItemIcon>
                                        {log.type === 'success' ? <CheckCircleIcon /> : log.type === 'update' ? <CheckCircleIcon color="primary" /> : log.type === 'skip' ? <WarningIcon color="warning" /> : <ErrorIcon />}
                                    </ListItemIcon>
                                    <ListItemText primary={log.message} secondary={log.details ? log.details.toString() : ''} />
                                </ListItem>
                            );
                        })}
                    </List>
                </div>
                <Typography variant="h6" style={{ marginTop: 20 }}>File Status:</Typography>
                <List>
                    <ListItem disableGutters>
                        <ListItemIcon>
                            <CheckCircleIcon color="success" />
                        </ListItemIcon>
                        <ListItemText primary={`Success Processes: ${fileStatus.rowsInserted || 0}`} secondary={`Last update: ${fileStatus.time}`} />
                    </ListItem>
                    <ListItem disableGutters>
                        <ListItemIcon>
                            <WarningIcon color="warning" />
                        </ListItemIcon>
                        <ListItemText primary={`Failure Processes: ${fileStatus.rowsSkipped || 0}`} secondary={`Last update: ${fileStatus.time}`} />
                    </ListItem>
                </List>
            </Container>
        </>
    );
}

export default VendorFolders;
