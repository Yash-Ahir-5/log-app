import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Select, MenuItem, Button, FormControl, InputLabel, Typography, Container, List, ListItem, ListItemText, ListItemIcon, Paper, Box, colors } from '@mui/material';
import { CheckCircle as CheckCircleIcon, Error as ErrorIcon } from '@mui/icons-material';

function VendorFolders() {
    const [folders, setFolders] = useState([]);
    const [selectedFolder, setSelectedFolder] = useState('');
    const [logs, setLogs] = useState([]);
    const [fileStatus, setFileStatus] = useState([]);

    useEffect(() => {
        fetchFolders();
        fetchFileStatus();
    }, []);

    const fetchFolders = async () => {
        try {
            const response = await axios.get('http://localhost:4000');
            setFolders(response.data);
        } catch (error) {
            console.error('Error fetching folders:', error);
        }
    };

    const fetchFileStatus = async () => {
        try {
            const response = await axios.get('http://localhost:4000/filestatus');
            // Sort the file status by time in descending order
            const sortedFileStatus = response.data.sort((a, b) => new Date(b.time) - new Date(a.time));
            setFileStatus(sortedFileStatus);
        } catch (error) {
            console.error('Error fetching file status:', error);
        }
    };

    const handleStartInserting = async () => {
        const eventSource = new EventSource(`http://localhost:4000/file/${selectedFolder}`);

        eventSource.onmessage = (event) => {
            const newLog = JSON.parse(event.data);
            setLogs(prevLogs => [...prevLogs, newLog]);
        };

        eventSource.onerror = (error) => {
            // console.error('EventSource error:', error);
            eventSource.close();
        };
    };

    const getTimeAgo = (timeString) => {
        const timeElapsed = new Date().getTime() - new Date(timeString).getTime();
        const seconds = Math.floor(timeElapsed / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);

        if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
        if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
        if (minutes > 0) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
        return `${seconds} second${seconds > 1 ? 's' : ''} ago`;
    };

    const getBackgroundColor = (type) => {
        switch (type) {
            case 'Success':
                return 'lightgreen';
            case 'Error':
                return 'lightcoral';
            default:
                return 'transparent';
        }
    };

    return (
        <Container maxWidth="lg" style={{ display: 'flex', justifyContent: 'space-between' , marginTop : "50px" }}>
            <div style={{ width: '40%' }}>
                <FormControl fullWidth>
                    <InputLabel id="folder-select-label">Folder</InputLabel>
                    <Select
                        labelId="folder-select-label"
                        id="folder-select"
                        value={selectedFolder}
                        label="Folder"
                        onChange={(e) => setSelectedFolder(e.target.value)}
                    >
                        <MenuItem value="">
                            <em>Select a folder</em>
                        </MenuItem>
                        {folders.map(folder => (
                            <MenuItem key={folder} value={folder}>{folder}</MenuItem>
                        ))}
                    </Select>
                </FormControl>
                <Button variant="contained" color="primary" onClick={handleStartInserting} style={{ marginTop: 20 }}>
                    Start Inserting
                </Button>
                <Typography variant="h6" style={{ marginTop: 20 }}>Logs:</Typography>
                <div style={{ height: '50vh', overflowY: 'auto' }}>
                    <List>
                        {logs.map((log, index) => {
                            const backgroundColor = getBackgroundColor(log.status);
                            return (
                                <ListItem key={index} disableGutters style={{ backgroundColor }}>
                                    <ListItemIcon>
                                        {log.status === 'Success' ? <CheckCircleIcon /> : <ErrorIcon />}
                                    </ListItemIcon>
                                    <ListItemText primary={log.message} secondary={log.details ? log.details.toString() : ''} />
                                </ListItem>
                            );
                        })}
                    </List>
                </div>
            </div>
            <div style={{ width: '40%' }}>
                <Typography variant="subtitle1" style={{ fontWeight: 'bold', color: 'green' }}>Success Processes:</Typography>
                <Box component={Paper} style={{ height: '50vh', overflowY: 'auto', padding: '10px', marginBottom: '20px' }}>
                    <List>
                        {fileStatus.filter(status => status.status === 'Success').map((status, index) => (
                            <ListItem key={index} disableGutters>
                                <ListItemText
                                    primary={`${status.vendorName}: Inserted - ${status.rowsInserted}  Updated - ${status.rowsUpdated}  Skipped - ${status.rowsSkipped}`}
                                    secondary={`Completed ${getTimeAgo(status.time)}`}
                                />
                            </ListItem>
                        ))}
                    </List>
                </Box>
                <Typography variant="subtitle1" style={{ fontWeight: 'bold', color: 'red' }}>Failure Processes:</Typography>
                <Box component={Paper} style={{ height: 'auto', overflowY: 'auto', padding: '10px' }}>
                    <List>
                        {fileStatus.filter(status => status.status !== 'Success').map((status, index) => (
                            <ListItem key={index} disableGutters>
                                <ListItemText
                                    primary={`${status.vendorName}: Inserted - ${status.rowsInserted}  Updated - ${status.rowsUpdated}  Skipped - ${status.rowsSkipped}`}
                                    secondary={`Completed ${getTimeAgo(status.time)}`}
                                />
                            </ListItem>
                        ))}
                    </List>
                </Box>
            </div>
        </Container>
    );
}

export default VendorFolders;
