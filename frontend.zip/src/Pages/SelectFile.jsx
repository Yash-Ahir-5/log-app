import React, { useState, useEffect } from 'react';
import axios from 'axios';

function VendorFolders() {
    const [folders, setFolders] = useState([]);
    const [selectedFolder, setSelectedFolder] = useState('');

    async function fetchFolders() {
        try {
            const response = await axios.get('http://localhost:4000');
            setFolders(response.data);
        } catch (error) {
            console.error('Error fetching folders:', error);
        }
    }

    useEffect(() => {
        fetchFolders();
    }, []);


    const handleStartInserting = async () => {
        if (selectedFolder) {
            console.log('Start inserting for folder:', selectedFolder);
            try {
                // Make a POST request to the uploadDoc API with the selected folder name
                const response = await axios.post('http://localhost:4000/file', { folderName: selectedFolder });
                console.log(response.data); // Assuming the API returns a success message
              } catch (error) {
                console.error('Error uploading document:', error);
              }
        } else {
            console.error('No folder selected');
        }
    };

    return (
        <div>
            <select value={selectedFolder} onChange={(e) => setSelectedFolder(e.target.value)}>
                <option value="">Select a folder</option>
                {folders.map(folder => (
                    <option key={folder} value={folder}>{folder}</option>
                ))}
            </select>
            <button onClick={handleStartInserting}>Start Inserting</button>
        </div>
    );
}

export default VendorFolders;