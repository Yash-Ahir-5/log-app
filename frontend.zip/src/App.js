import './App.css';
import VendorFolders from './Pages/SelectFile';

function App() {
  return (
    <VendorFolders/>
  );
}

export default App;
