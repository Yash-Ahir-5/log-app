import './App.css';
// import VendorFolders from './Pages/SelectFile';
import VendorFolders from './Pages/File';

function App() {
  return (
    // <VendorFolders/>
    <VendorFolders/>
  );
}

export default App;
